﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CsPoTestClassLibraryEF.Model
{
    public partial class CsItem

    {
        public static CsPoTestEntities dbContext = new CsPoTestEntities();
        public static List<CsItemCategory> getItemCategory()
        {
            List<CsItemCategory> itemCategoryList = new List<CsItemCategory>();

            try
            {
                itemCategoryList =
                    (from ic in dbContext.CsItemCategories
                     where ic.description != "Studio Rooms"
                     orderby ic.description
                     select ic).ToList();

                     

            }
            catch(Exception ex)
            {
                throw ex;
            }

            return itemCategoryList;


        }
        public static List<CsItemSubcategory> getItemSubcategoryList(int categoryID)
        {
            List<CsItemSubcategory> itemSubcategoryList = new List<CsItemSubcategory>();
            

            try
            {
                itemSubcategoryList =
                    (from isc in dbContext.CsItemSubcategories
                     orderby isc.description
                     where isc.itemCategoryID == categoryID
                     select isc).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return itemSubcategoryList;
        }
        public static List<CsItem> getItemList(int subcategoryID)
        {
            List<CsItem> itemList = new List<CsItem>();
            try
            {
                itemList =
                    (from i in dbContext.CsItems
                     orderby i.description
                     where i.itemSubcategoryID ==  subcategoryID
                     select i).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return itemList;

        }
        
       public static List<CsItemSubcategory> getStudioRooms()
        {
            List<CsItemSubcategory> studioRoomList = new List<CsItemSubcategory>();


            try
            {
                studioRoomList =
                    (from sr in dbContext.CsItemSubcategories
                     orderby sr.description
                     where sr.description.Contains("Room") || sr.description.Contains("Master")
                     select sr).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return studioRoomList;
        }


        public static string getRentalPrice(int itemID)
        {


            var rentalPrice = (from i in dbContext.CsItems
                               select i.rentalPrice);

            return rentalPrice.ToString();           
        }


    }
}
