﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsPoTestClassLibraryEF.Model
{
    public partial class CsEmployeeForHire
    {
        public static CsPoTestEntities dbContext = new CsPoTestEntities();
        public static List<CsEmployeeForHire> getEmployeeForHire()
        {
            List<CsEmployeeForHire> employeeList = new List<CsEmployeeForHire>();

            try
            {
                employeeList =
                    (from e in dbContext.CsEmployeeForHires
                     orderby e.CsPerson.lastName
                     select e).ToList();



            }
            catch (Exception ex)
            {
                throw ex;
            }

            return employeeList;

        }

        public string LastFirstName
        {
            get
            {
                return this.CsPerson.lastName + ", " + this.CsPerson.firstName;
            }


        }
    }
}
