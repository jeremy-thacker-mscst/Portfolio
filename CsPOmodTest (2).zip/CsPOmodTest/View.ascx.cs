﻿/*
' Copyright (c) 2016  Christoc.com
'  All rights reserved.
' 
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
' DEALINGS IN THE SOFTWARE.
' 
*/

using System;
using DotNetNuke.Security;
using DotNetNuke.Services.Exceptions;
using DotNetNuke.Entities.Modules;
using DotNetNuke.Entities.Modules.Actions;
using DotNetNuke.Services.Localization;
using CsPoTestClassLibraryEF.Model;
using System.Windows.Forms;

namespace Christoc.Modules.CsPOmodTest
{
    /// -----------------------------------------------------------------------------
    /// <summary>
    /// The View class displays the content
    /// 
    /// Typically your view control would be used to display content or functionality in your module.
    /// 
    /// View may be the only control you have in your project depending on the complexity of your module
    /// 
    /// Because the control inherits from CsPOmodTestModuleBase you have access to any custom properties
    /// defined there, as well as properties from DNN such as PortalId, ModuleId, TabId, UserId and many more.
    /// 
    /// </summary>
    /// -----------------------------------------------------------------------------
    public partial class View : CsPOmodTestModuleBase, IActionable
    {
        protected void Page_Load(object sender, EventArgs e)
        {


            try
            {


                if (!Page.IsPostBack)
                {
                    loadItemCategory();
                    loadItemSubcategory();
                    //loadItem();
                    loadEmployee();
                    loadStudioRoom();
                }

            }
            catch (Exception exc) //Module failed to load
            {
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        public ModuleActionCollection ModuleActions
        {
            get
            {
                var actions = new ModuleActionCollection
                    {
                        {
                            GetNextActionID(), Localization.GetString("EditModule", LocalResourceFile), "", "", "",
                            EditUrl(), false, SecurityAccessLevel.Edit, true, false
                        }
                    };
                return actions;
            }
        }

       
        
        private void loadStudioRoom()
        {
            try
            {
                this.studioRoomDropDownList.DataSource = CsItem.getStudioRooms();
                this.studioRoomDropDownList.DataMember = "itemSubcategoryID";
                this.studioRoomDropDownList.DataTextField = "description";
                this.studioRoomDropDownList.DataBind();
                this.studioRoomDropDownList.SelectedIndex = 0;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        // Populate itemCategoryDropDownList 
        private void loadItemCategory()
        {
            try
            {
                this.itemCategoryDropDownList.DataSource = CsItem.getItemCategory();
                this.itemCategoryDropDownList.DataValueField = "itemCategoryID";
                this.itemCategoryDropDownList.DataTextField = "description";
                this.itemCategoryDropDownList.DataBind();
                this.itemCategoryDropDownList.SelectedIndex = 0;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        // Populate itemSubCategoryDropDownList
        private void loadItemSubcategory()
        {
            try
            {
                int categoryID = Int32.Parse(this.itemCategoryDropDownList.SelectedValue);
                this.itemSubcategoryDropDownList.DataSource = CsItem.getItemSubcategoryList(categoryID);
                this.itemSubcategoryDropDownList.DataValueField = "itemSubcategoryID";
                this.itemSubcategoryDropDownList.DataTextField = "description";
                this.itemSubcategoryDropDownList.DataBind();
                this.itemSubcategoryDropDownList.SelectedIndex = 0;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        // populate itemDropDownList
        private void loadItem()
        {
            try
            {
                int subcategoryID = Int32.Parse(this.itemSubcategoryDropDownList.SelectedValue);
                this.itemDropDownList.DataSource = CsItem.getItemList(subcategoryID);
                this.itemDropDownList.DataValueField = "itemID";
                this.itemDropDownList.DataTextField = "description";
                this.itemDropDownList.DataBind();
                this.itemDropDownList.SelectedIndex = 0;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void loadEmployee()
        {
            try
            {
                this.employeeForHireDropDownList.DataSource = CsEmployeeForHire.getEmployeeForHire();
                this.employeeForHireDropDownList.DataValueField = "personID";
                this.employeeForHireDropDownList.DataTextField = "LastFirstName";
                this.employeeForHireDropDownList.DataBind();
                this.employeeForHireDropDownList.SelectedIndex = 0;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void addRoomButton_Click(object sender, EventArgs e)
        {
            roomListBox.Items.Add(studioRoomDropDownList.SelectedItem);

            var roomTotal = Decimal.Parse(roomPricePerDayLabel.Text) * Decimal.Parse(quantityDropDownList1.SelectedValue);
            roomTotalLabel.Text = roomTotal.ToString();

            overallTotalLabel.Text = roomTotal.ToString();
        }

        protected void addGearButton_Click(object sender, EventArgs e)
        {
            gearListBox.Items.Add(itemDropDownList.SelectedItem);
            
            var gearTotal = Decimal.Parse(itemPriceLabel.Text) * Decimal.Parse(quantityDropDownList2.SelectedValue);
            gearTotalLabel.Text = gearTotal.ToString();
            
        }

        protected void hireEmpButton_Click(object sender, EventArgs e)
        {
            empListBox.Items.Add(employeeForHireDropDownList.SelectedItem);
            var empTotal = Decimal.Parse(empPricePerHourLabel.Text) * Decimal.Parse(daysHiredDropDownList.SelectedValue);
            empTotalLabel.Text = empTotal.ToString();
        }

        protected void itemCategoryDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            loadItemSubcategory();
        }

        protected void itemSubcategoryDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            loadItem();
        }

        protected void itemDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {

            this.itemPriceLabel.Text = "15.00";
            //loadItemPrice();
        }

        protected void loadItemPrice()
        {
            int itemID = Int32.Parse(this.itemDropDownList.SelectedValue);
            this.itemPriceLabel.Text = CsItem.getRentalPrice(itemID);

        }

        protected void studioRoomDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.roomPricePerDayLabel.Text = "150.00";
        }

        protected void employeeForHireDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.empPricePerHourLabel.Text = "40.00";
        }
    } 
}